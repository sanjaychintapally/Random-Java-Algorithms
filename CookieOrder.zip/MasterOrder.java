package com.company;
import java.util.ArrayList;

public class MasterOrder {

    private ArrayList<CookieOrder> orders;

    public MasterOrder() {
        orders = new ArrayList<CookieOrder>();
        orders.add(new CookieOrder("Chocolate Chip", 1));
        orders.add(new CookieOrder("Shortbread", 5));
        orders.add(new CookieOrder("Macaroon", 2));
        orders.add(new CookieOrder("Chocolate Chip", 3));
    }

    public int getTotalBoxes() {
        int sum = 0;
        for(int i = 0; i < orders.size(); i++) {
            sum += orders.get(i).getNumBoxes();
        }
        return sum;
    }

    public int removeVariety(String cookieVar) {
        int count = 0;
        for(int i = 0; i < orders.size(); i++) {
            if(orders.get(i).getVariety().equals(cookieVar)) {
                count += orders.get(i).getNumBoxes();
                orders.remove(i);
                i--;
            }
        }
        return count;
    }

    public static void main(String[] args) {
	    MasterOrder newOrder = new MasterOrder();
        System.out.println(newOrder.getTotalBoxes());
        System.out.println(newOrder.removeVariety("Chocolate Chip"));
    }
}
