package com.company;

public class CookieOrder {

    private String type;
    private int num;

    public CookieOrder(String variety, int numBoxes) {
        type = variety;
        num = numBoxes;
    }

    public String getVariety() {
        return type;
    }

    public int getNumBoxes() {
        return num;
    }
}
