    package com.company;
import java.util.ArrayList;

public class CardShuffler {

    public static void main(String[] args) {

        // Creates a Deck of Cards
        ArrayList<Card> deck = new ArrayList<Card>();
        String[] suits = {"Clubs", "Diamonds", "Spades", "Hearts"};
        for (String suit : suits) {
            for (int i = 1; i <= 13; i++) {
                deck.add(new Card(suit, i));
            }
        }
        System.out.println("Display New Deck");
        displayDeck(deck);

        // Insertion Shuffle
        for (int i = 0; i < 100000; i++) {
            Card tempCard = deck.remove((int) (Math.random() * (deck.size())));
            deck.add(0, tempCard);
        }
        System.out.println("\nDisplay Insertion Shuffled Deck");
        displayDeck(deck);

        // Deals the Shuffled Cards to Two Players
        ArrayList<Card> p1Hand = new ArrayList<Card>();
        ArrayList<Card> p2Hand = new ArrayList<Card>();
        while (deck.size() > 0) {
             if (deck.size() % 2 == 0) {
                  p1Hand.add(deck.remove(0));
             }
             else {
                  p2Hand.add(deck.remove(0));
             }
        }
        System.out.println("\nPlayer 1 Deck");
        displayDeck(p1Hand);
        System.out.println("\nPlayer 2 Deck");
        displayDeck(p2Hand);

//      // Merge Shuffle
//      ArrayList<Card> tempDeck = new ArrayList<Card>();
//      for (int i = 0; i < 1000; i++) {
//          while (deck.size() > 0) {
//              if (deck.size() % 2 != 0) {
//                  tempDeck.add(deck.remove(0));
//              } else {
//                  tempDeck.add(deck.remove(deck.size() / 2));
//              }
//          }
//          while (tempDeck.size() > 0) {
//              deck.add(tempDeck.remove(0));
//          }
//      }
//      System.out.println("\nDisplay Merge Shuffled Deck");
//      displayDeck(deck);

//      //Sorts the Card According to Number
//      for (int i = 0; i < deck.size() - 1; i++) {
//          int minVal = deck.get(i).getValue();
//          int minLoc = i;
//          for (int j = i + 1; j < deck.size(); j++) {
//              if (deck.get(j).getValue() < minVal) {
//                  minVal = deck.get(j).getValue();
//                  minLoc = j;
//              }
//          }
//          Card temp = deck.get(i);
//          deck.set(i, deck.get(minLoc));
//          deck.set(minLoc, temp);
//      }
//      System.out.println("\nDisplay Sorted Deck");
//        displayDeck(deck);
    }
        // Prints the Deck of Cards
        public static void displayDeck(ArrayList <Card> d) {
            for (int i = 0; i < d.size(); i++) {
                System.out.println(d.get(i));
        }
    }
}

