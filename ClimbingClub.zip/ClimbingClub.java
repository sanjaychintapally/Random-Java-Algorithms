package com.company;
import java.util.ArrayList;

public class ClimbingClub {

    private ArrayList<ClimbInfo> climbList;

    public ClimbingClub() {
        climbList = new ArrayList<ClimbInfo>();
        climbList.add(new ClimbInfo("Sanjay", 435));
    }

    public void addClimb(String peakName, int climbTime) {
        for(int i = 0; i < climbList.size(); i++) {
            if(peakName.compareTo(climbList.get(i).getName()) <= 0) {
                climbList.add(i, new ClimbInfo(peakName, climbTime));
                break;
            }
        }
        if(peakName.compareTo(climbList.get(climbList.size() - 1).getName()) > 0) {
            climbList.add(new ClimbInfo(peakName, climbTime));
        }
    }

    public static void main(String[] args) {
        ClimbingClub hikerClub = new ClimbingClub();
        hikerClub.addClimb("Monadnock", 274);
        hikerClub.addClimb("Whiteface", 301);
        hikerClub.addClimb("Algonquin", 225);
        hikerClub.addClimb("Monadnock", 344);
        System.out.println(hikerClub.climbList.get(4).getName());
    }
}
